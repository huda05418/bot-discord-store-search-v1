module.exports = {
    roles: {
        member: '1456048197930848491',
        admin: '1456047885194887228'
    },
    channels: {
        welcome: '1455464087336128553', // chanle welcome
        ticket_category: '1456055211826216961',
        admin_dashboard: '1456048420681941058', // untuk panell
        status_info: '1456049340979351562', // ini chanle ticket id
        testimonial: '1456050661396447305'
    },
    images: {
        open: 'https://media.discordapp.net/attachments/1427619098812219453/1427902956119916664/10151.gif?ex=695762c1&is=69561141&hm=e673039bae3a852e818111f1bfe72f399141ff41d384202523fcbe6191a97011&=&width=639&height=360',
        close: 'https://media.discordapp.net/attachments/1456048421902487658/1456057792346587168/ChatGPT_Image_6_Des_2025_16.32.00.png?ex=6957a3bd&is=6956523d&hm=c892f9ba4bcc45bc1ea44532bdff3ee640c131e2b0108c56ec101b4f297ca2d0&=&format=webp&quality=lossless&width=1296&height=864'
    }
};